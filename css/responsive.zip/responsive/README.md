### Utilise le system de Grid, ainsi que les MediaQueries vus dans l'introduction, ton but est d'avoir le même rendu que les images suivantes.

Toutes les couleurs que tu ne vois pas sur les images doivent être cachées

<span style="color:red">**Ne pas toucher au fichier initial.css, ecrire votre CSS dans style.css**</span>


1. Pour les tailles d'écran supérieur a 1023px
![sup1023px](img/pc.png)
 
<br><br><br>

2. Pour les tailles d'écran supérieur a 768px & inférieur a 1022px
![between768-1022px](img/tablette.png)

<br><br><br>

3. Pour les tailles d'écran inférieur a 767px **<span style="color:red">(Toutes les couleurs sont affichées, chacune d'elles prend toute la largeur. Elles sont les unes en dessous des autres via un scroll)</span>**
![inf767px](img/mobile.png)
