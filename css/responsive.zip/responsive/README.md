### Utilise le system de Grid, ainsi que les MediaQueries vus dans l'introduction, ton but est d'avoir le même rendu que les images suivantes.

*Toutes les couleurs que tu ne vois pas sur les images doivent être cachées*


1. Pour les tailles d'écran supérieur a 1023px
![sup1023px](img/pc.png)
 
<br><br><br>

2. Pour les tailles d'écran supérieur a 768px & inférieur a 1023px
![sup1023px](img/tablette.png)

<br><br><br>

3. Pour les tailles d'écran inférieur a 767px (Toutes les couleurs sont affichées, chacune d'elles prend toute la largeur.)
![sup1023px](img/mobile.png)
